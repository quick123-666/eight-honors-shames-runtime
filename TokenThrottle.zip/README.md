<!-- 项目徽章:状态 / 许可 / Rust 版本 -->
![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
![Rust](https://img.shields.io/badge/Rust-1.97%2B-orange.svg)

# TokenThrottle 节流阀

> 分析 QClaw / openclaw 真实 token 消耗,定位可压缩的 tool 输出,配合「八耻八荣」纪律落地省 token。

一句话:**先量化(分析脚本)→ 立规矩(纪律文件)→ 复测(周期性对比)**,把 token 消耗从"感觉很多"变成"知道省在哪"。

## 目录

- [About](#about)
- [Built With](#built-with)
- [Getting Started](#getting-started)
- [Usage](#usage)
- [输出说明](#输出说明)
- [Roadmap](#roadmap)
- [License](#license)
- [Acknowledgments](#acknowledgments)

---

## About

### 问题

QClaw / openclaw agent 日常对话中 **tool 输出(toolResult)占 token 消耗过半**。实测 7 天数据(2026-08-03 ~ 08-09):

| 角色 | tokens | 占比 |
|---|---|---|
| toolResult | 163,052 | 53.3% ← **压缩可省的大头** |
| assistant | 138,710 | 45.3% |
| user | 4,367 | 1.4% |
| **总估算** | **306,129** | |

单次 `exec` 输出最高 **5,427 tok**(一条命令就烧掉 5K+ token)。

### 解决方案

- **量化**:Rust CLI 读 QClaw 转录库,按角色 / 会话 / 工具 / 输出大小四维统计;
- **立规**:`RULES.md` + `AGENTS.md` 沉淀「八耻八荣」AI 协作纪律 + 省 token 操作纪律;
- **复测**:`--json` / `--csv` 导出基线,周期性对比验证效果。

### 核心特性

- **四维统计**:按角色、会话、工具调用频率、tool 输出大小分布
- **pi 缓存分析**(`--pi`):扫 pi 会话,统计 Prompt 缓存命中率与费用(实测 98.3% 命中 / 省 81%)
- **三种输出**:人类可读文本 / JSON(`--json`)/ CSV 四表导出(`--csv`)
- **自动推导**:时间范围、总量、占比全部从数据计算,不写死
- **中英混合估算**:3 char/token,与历史 Python 版保持等价(偏差 <0.2%)

---

## Built With

- [Rust](https://www.rust-lang.org/)(edition 2024)
- [rusqlite](https://crates.io/crates/rusqlite)(bundled,sqlite 只读)
- [clap](https://crates.io/crates/clap)(CLI 参数)
- [serde_json](https://crates.io/crates/serde_json)(JSON 输出)
- [csv](https://crates.io/crates/csv)(CSV 导出)
- [anyhow](https://crates.io/crates/anyhow)(错误处理)

---

## Getting Started

### Prerequisites

- Rust 1.97+(`rustup default stable`)

### Installation

```bash
cargo build --release
```

---

## Usage

```bash
# 1. 文本报告(默认库)
cargo run --release

# 2. 指定转录库
cargo run --release -- --db C:/Users/Administrator/.openclaw/agents/main/agent/openclaw-agent.sqlite

# 3. JSON 输出(供脚本/复测对比)
cargo run --release -- --json > baseline.json

# 4. CSV 导出 4 张表(roles/sessions/tools/outputs)
cargo run --release -- --csv out/csv

# 5. 控制 Top N
cargo run --release -- --top 10

# 6. pi 会话缓存/费用分析(扫 ~/.pi/agent/sessions)
cargo run --release -- --pi
cargo run --release -- --pi --json > pi_baseline.json
cargo run --release -- --pi --pi-dir <自定义会话目录>
```

---

## 输出说明

**文本报告**:时间范围、总量、按角色占比、按会话、工具频率 Top、tool 输出大块 Top。

**JSON**(`--json`):结构化输出,含 `time_range` / `totals` / `roles` / `sessions` / `tools` / `top_outputs`,适合保存基线做对比。

**pi 模式**(`--pi`):扫 pi 会话 jsonl,输出缓存命中率、按模型明细、无缓存 vs 有缓存费用对比、pi 实际记账——直接回答"省 token 90% 在哪"。

**CSV**(`--csv <dir>`):导出 4 张表到指定目录:

| 文件 | 内容 |
|---|---|
| `roles.csv` | role / tokens / percent / count |
| `sessions.csv` | session_id / total / user / assistant / toolResult |
| `tools.csv` | tool / count(调用频率) |
| `outputs.csv` | tokens / session_id / seq / preview(最大输出 Top N) |

---

## Roadmap

- [x] v0.1.0 Rust 重写(等价复刻 Python 版 + JSON/CSV)
- [x] v0.1.1 `--pi` 模式(pi 会话缓存/费用分析)
- [x] 省 token 操作纪律写入 AGENTS.md / RULES.md
- [x] Python 版归档 `archive/analyze_tokens.py`
- [ ] v0.2.0 增量分析(对比两次运行的 token 变化)
- [ ] v0.2.0 按工具聚合输出大小(定位最烧钱的 exec 命令)
- [ ] 效果复测报告(1~2 周后对比 toolResult 占比是否下降)

---

## License

[MIT](./LICENSE)

---

## Acknowledgments

- 「八耻八荣」AI 协作准则来源:`jshgd/ai-coding-八耻八荣.md`(mini-mp-agent v1.9.4 整理)
- QClaw 转录库:openclaw 会话数据(本地只读分析,不采集)
