# TokenThrottle 技术报告

> 项目代号:**TokenThrottle(节流阀)**
> 目标:分析真实 token 消耗 → 以「八耻八荣」纪律约束 agent 行为 → 压缩 tool 输出,省 token
> 报告日期:2026-08-09

---

## 1. 项目背景与目标

QClaw(openclaw)与 pi 两个 agent 在日常工作中消耗大量 token,其中 **tool 输出(toolResult)占比过半**,存在明确压缩空间。本项目三步走:

1. **量化**:写脚本精确分析真实 token 消耗,找出可省的大头;
2. **立规**:以「八耻八荣」AI 协作准则为骨架,沉淀出可执行的省 token 操作纪律;
3. **复测**:周期性重跑分析脚本,对比改造前后占比,验证效果。

---

## 2. 八耻八荣准则配置工作

### 2.1 来源与引入

准则原文来自 `C:/Users/Administrator/Desktop/jshgd/ai-coding-八耻八荣.md`(2026-08-08 由 mini-mp-agent v1.9.4 整理),2026-08-09 引入本项目。

### 2.2 落地为两份文件

| 文件 | 定位 | 要点 |
|---|---|---|
| `AGENTS.md` | 精简命令式清单,pi 启动自动加载 | 11 条「八耻八荣」命令式 + 通用偏好 + 探针验证机制 |
| `RULES.md` | 正式手册,完整原文 | 核心定位表、11 条准则全文、执行映射附录 |

### 2.3 设计要点

- **八耻八荣 11 条**(含 3 条补充):以啃接口为耻/以认真查阅为荣、以模糊执行为耻/以寻求确认为荣、以妄想业务为耻/以人类确认为荣、以创造接口为耻/以复用现有为荣、以跳过验证为耻/以主动调试为荣、以破坏架构为耻/以遵循规范为荣、以假装理解为耻/以诚实无知为荣、以盲目修改为耻/以谨慎重构为荣、以擅自执行为耻/以确认后行为荣、以无备份改为耻/以备份先行/确认后改为荣、以永久删除为耻/以回收站删除为荣。
- **执行映射**:每条准则映射到本项目的具体动作(如准则 1 → `codegraph_explore` 先查)。
- **探针机制**:AGENTS.md 内嵌「信号 A / 信号 B」验证规则,新会话首答可自查两份文件是否都已加载。

---

## 3. token 消耗分析(`analyze_tokens.py`)

### 3.1 数据源与方法

- 数据源:`C:/Users/Administrator/.openclaw/agents/main/agent/openclaw-agent.sqlite`(QClaw 会话转录库,只读)
- 估算规则:中英混合按 `len(text) // 3` token 估算
- 提取逻辑:按会话 + 角色统计,`assistant` / `toolResult` / `user` 三类;工具调用从 assistant 消息的 block 提取;另输出 tool 输出大小分布找大块

### 3.2 基线数据(2026-08-03 13:50 ~ 2026-08-09 19:25,7 天)

| 指标 | 数值 |
|---|---|
| 总估算 | 306,552 tokens |
| 消息数 / 会话数 | 1,507 条 / 4 个会话 |
| toolResult | 163,052 tok(53.2%)← 压缩可省的大头 |
| assistant | 139,133 tok(45.4%)|
| user | 4,367 tok(1.4%)|
| 最大单次 tool 输出 | 5,427 tok(exec 输出)|

**工具调用频率 Top**:`exec` 182 次、`edit` 50、`read` 45、`wait` 11、`process` 8。

**结论**:tool 输出占 53.2%,是最大可省空间;exec 是最常用且输出最大的工具。

### 3.3 脚本 bug 修复记录

初版存在 3 个问题,已修复:

1. **工具统计恒为空**:QClaw 消息中工具调用块类型是 `toolCall`(字段 `name`/`arguments`),脚本误判为 `tool_use` 永不匹配 → 改为 `toolCall`,Top 20 正常输出;
2. **token 估算偏高**:thinking 块被整块 dumps(含签名)、toolCall 未单独处理 → 改为只提取 `thinking` 文本与 `arguments`,总数从 368K 修正为 306K,更接近真实;
3. **控制台乱码 + 时间写死**:加 `sys.stdout.reconfigure(encoding='utf-8')`;时间范围改为从数据自动推导(毫秒时间戳换算)。

---

## 4. 省 token 纪律落地

### 4.1 A:压缩 tool 输出(已落地)

在 `AGENTS.md` / `RULES.md` 新增「省 token 操作纪律」章节,强制约束 pi agent 的 tool 输出量:

- bash 输出一律限流(`| head -N` / `grep` 过滤;禁 `ls -R`、`cat` 大文件、`find /`);
- read 用 `offset`/`limit` 按需分段;
- 查代码优先 `codegraph_explore` 一次打包,避免多轮 grep/read 循环;
- 大输出命令先给摘要(`git diff --stat`、`tail -50`、`grep -i error`);
- 上下文最小化,汇报只带关键片段;
- 用 `analyze_tokens.py` 周期性复测(基线 53.2%),验证效果。

### 4.2 B:减少 thinking 消耗(调查结论:当前模型下不可行)

- 当前默认模型 `deepseek-v4-flash` 的 `thinkingLevelMap` 仅暴露 `high` / `max` 两档,`minimal`/`low`/`medium` 均为 `null`(不支持);
- 当前 `defaultThinkingLevel: "high"` 已是最低可用档,`--thinking low` 会被 pi clamp 回 `high`;
- 备选:minimax 系列 `thinkingLevelMap` 未定义(omitted),标准档理论上可用,但换模型涉及能力/价格权衡,暂不执行 → **B 保持现状**。

---

## 5. Rust 迁移记录(v0.1.0)

### 5.1 为什么重写

沿用 mini-mp-agent Python → Rust 的成功先例:Python 版 `analyze_tokens.py` 已稳定运行,但需要更专业的 CLI 工具形态(参数、JSON/CSV 输出、可编译分发)。Rust 单二进制交付,无 Python 运行时依赖。

### 5.2 技术选型

| 依赖 | 用途 | 版本 |
|---|---|---|
| `rusqlite`(bundled) | 读 sqlite 转录库,同步轻量 | 0.40.2 |
| `clap`(derive) | CLI 参数(`--db`/`--top`/`--json`/`--csv`) | 4.6.6 |
| `serde_json` | JSON 输出 | 1.0.151 |
| `csv` | CSV 四表导出 | 1.4.0 |
| `anyhow` | 错误处理 | 1.0.104 |
| `chrono` | 毫秒时间戳 → 本地时间(GMT+8) | — |

### 5.3 模块结构

```
src/
├── main.rs     ← 入口 + clap CLI 解析
├── analyze.rs  ← 核心统计(角色/会话/工具/输出四维)
└── report.rs   ← 输出层(文本 / JSON / CSV)
```

### 5.4 等价性验证(与 Python 基线对比)

| 指标 | Python 版 | Rust 版 | 偏差 |
|---|---|---|---|
| 总估算 | 306,552 | 306,129 | 0.14% |
| toolResult | 163,052 | 163,052 | 0 |
| user | 4,367 | 4,367 | 0 |
| 工具频率(exec/edit/read) | 182/50/45 | 182/50/45 | 0 |

差异来自 JSON 序列化细节(`json.dumps` vs `serde_json` 空白/键序),业务逻辑完全等价。

### 5.5 归档

Python 版 `analyze_tokens.py` 移入 `archive/` 保留作参考(不删除)。

---

## 6. pi 侧缓存实测(--pi 模式)

### 6.1 背景

市面"省 token 90%"项目的真相:**Prompt 缓存(计费层)**,不是内容压缩。相同前缀命中缓存后,输入 token 按缓存价计费(deepseek:0.14→0.0028,便宜 50 倍;MiniMax-M3:0.30→0.06,便宜 5 倍)。

### 6.2 实测方法

pi 每条 assistant 消息带 `usage` 字段(input/cacheRead/cacheWrite/output/cost),扫 `~/.pi/agent/sessions/*.jsonl` 全量统计。工具新增 `--pi` 模式。

### 6.3 实测结果(2026-08-09,16,723 条带 usage 消息)

| 指标 | 数值 |
|---|---|
| 未命中输入 | 61,189,910 tok |
| 缓存命中 | 3,590,677,171 tok |
| **输入侧缓存命中率** | **98.32%** |
| 假设无缓存花费 | $909.35 |
| 当前花费(缓存生效) | $169.67 |
| **缓存帮省** | **$739.70 = 81.3%** |

按模型明细:

| 模型 | 消息数 | 命中率 | 记账 |
|---|---|---|---|
| MiniMax-M3 | 12,705 | 97.7% | $164.58 |
| deepseek-v4-flash | 3,769 | 99.5% | $4.88 |
| deepseek-v4-pro | 249 | 99.6% | $0.22 |

### 6.4 结论

1. **pi 侧缓存早已生效**(98.32% 命中),"省 90%"在计费层已实现(81.3%,未达 90% 是因为 MiniMax 缓存价只便宜 5 倍,占大头);
2. `supportsStore: false` 不影响——deepseek/MiniMax 自动缓存;
3. 剩余 1.68% 未命中来自前缀变化,优化空间小;
4. **QClaw 侧缓存尚未验证**(其转录库未记录 usage),是下一步待查点。

---

## 7. 项目结构

```
kimi_code_test/
├── TokenThrottle.zip         ← 交付包(排除 target/ 与 .git)
└── TokenThrottle/            ← 项目根(独立 git 仓库,main 分支)
    ├── src/                  ← Rust 源码(main / analyze / pi_analyze / report)
    │   ├── main.rs
    │   ├── analyze.rs        ← QClaw 转录库统计
    │   ├── pi_analyze.rs     ← pi 会话缓存/费用统计
    │   └── report.rs         ← 输出层(文本/JSON/CSV)
    ├── Cargo.toml / Cargo.lock
    ├── archive/analyze_tokens.py  ← Python 版归档
    ├── AGENTS.md             ← 精简纪律(含省 token 操作纪律)
    ├── RULES.md              ← 八耻八荣完整手册 + 纪律细则
    ├── TECHNICAL_REPORT.md   ← 本报告
    ├── README.md             ← GitHub 主页(用法/输出说明/Roadmap)
    ├── LICENSE               ← MIT
    └── .gitignore            ← target/ out/ IDE 等
```

> 原工作目录 `kimi_code_test/` 根下的 AGENTS.md / RULES.md / analyze_tokens.py 保留作备份(与 TokenThrottle 内版本一致)。

---

## 8. 当前状态与下一步

| 事项 | 状态 |
|---|---|
| token 分析脚本(Python 版) | ✅ 完成,已归档 archive/ |
| **Rust 重写 v0.1.0(等价 + JSON/CSV)** | ✅ 完成,0 warning 编译 |
| 基线数据采集 | ✅ 306K tok / toolResult 53.3% |
| 八耻八荣纪律配置(AGENTS/RULES) | ✅ 完成 |
| A:压缩 tool 输出纪律 | ✅ 已写入,自下一会话生效 |
| B:减少 thinking | ⏸ 保持现状(模型不支持降档) |
| GitHub 格式(README/LICENSE/.gitignore) | ✅ 完成 |
| **pi 缓存实测(--pi 模式)** | ✅ 完成,命中率 98.32% / 省 81.3% |
| QClaw 侧缓存验证 | ⏳ 待查(转录库未记录 usage) |
| 效果复测 | ⏳ 待周期性执行(建议 1~2 周后重跑对比) |

**建议下一步**:
1. 1~2 周后重跑 `token-throttle --json`,对比 toolResult 占比是否低于 53.3%;
2. v0.2.0:增量分析(对比两次运行)、按工具聚合输出大小(定位最烧钱的 exec 命令);
3. 验证 QClaw(MiniMax-M3)侧 Prompt 缓存是否生效(转录库无 usage,需从 openclaw 日志/API 响应验证);
4. 若追求 thinking 降档,评估切换 minimax 模型的成本与收益;
5. 可将纪律推广到 QClaw 侧(对 exec 输出做截断/摘要)。
