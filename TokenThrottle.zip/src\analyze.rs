//! 核心统计逻辑:读 QClaw 转录库,估算各角色/会话/工具/输出的 token 消耗。
//! 与 Python 版 analyze_tokens.py 保持等价(中英混合按 3 char/token 估算)。

use anyhow::Result;
use rusqlite::Connection;
use serde_json::Value;
use std::collections::BTreeMap;

/// 默认数据库路径(QClaw 会话转录库,只读)
pub const DEFAULT_DB: &str =
    "C:/Users/Administrator/.openclaw/agents/main/agent/openclaw-agent.sqlite";

#[derive(Default, Debug)]
pub struct RoleStat {
    pub tokens: u64,
    pub count: u64,
}

#[derive(Debug)]
pub struct OutputRec {
    pub tokens: u64,
    pub sid: String,
    pub seq: i64,
    pub preview: String,
}

#[derive(Default, Debug)]
pub struct Stats {
    pub start_ms: i64,
    pub end_ms: i64,
    pub grand_tokens: u64,
    pub msg_count: u64,
    /// sid -> role -> tokens
    pub sessions: BTreeMap<String, BTreeMap<String, u64>>,
    /// role -> 统计
    pub roles: BTreeMap<String, RoleStat>,
    /// tool 名 -> 调用次数
    pub tools: BTreeMap<String, u64>,
    /// toolResult 输出记录(用于找大块)
    pub outputs: Vec<OutputRec>,
}

/// 估算 token:中英混合按 3 char/token(与 Python `len(text)//3` 等价)
pub fn est_tokens(text: &str) -> u64 {
    let n = text.chars().count() as u64;
    if n == 0 {
        0
    } else {
        (n / 3).max(1)
    }
}

/// 提取 content(string 或 block 数组)的纯文本
pub fn extract_text(content: &Value) -> String {
    match content {
        Value::String(s) => s.clone(),
        Value::Array(items) => {
            let mut parts = Vec::new();
            for c in items {
                if let Value::Object(m) = c {
                    let kind = m.get("type").and_then(|v| v.as_str()).unwrap_or("");
                    match kind {
                        "text" => parts.push(
                            m.get("text").and_then(|v| v.as_str()).unwrap_or("").to_string(),
                        ),
                        "thinking" => parts.push(
                            m.get("thinking").and_then(|v| v.as_str()).unwrap_or("").to_string(),
                        ),
                        "toolCall" => parts.push(
                            m.get("arguments").cloned().unwrap_or(Value::Null).to_string(),
                        ),
                        _ => parts.push(c.to_string()),
                    }
                } else {
                    parts.push(c.to_string());
                }
            }
            parts.join("\n")
        }
        _ => content.to_string(),
    }
}

/// 读取库并统计
pub fn analyze(conn: &Connection) -> Result<Stats> {
    let mut st = Stats::default();
    let mut stmt = conn.prepare(
        "SELECT session_id, seq, event_json, created_at FROM transcript_events ORDER BY created_at",
    )?;
    let mut rows = stmt.query([])?;

    while let Some(row) = rows.next()? {
        let sid: String = row.get(0)?;
        let seq: i64 = row.get(1)?;
        let ej: String = row.get(2)?;

        let ev: Value = match serde_json::from_str(&ej) {
            Ok(v) => v,
            Err(_) => continue,
        };
        if ev.get("type").and_then(|v| v.as_str()) != Some("message") {
            continue;
        }
        let Some(msg) = ev.get("message") else { continue };
        let role = msg.get("role").and_then(|v| v.as_str()).unwrap_or("?").to_string();
        let content = msg.get("content").cloned().unwrap_or(Value::Null);
        let text = extract_text(&content);
        let t = est_tokens(&text);

        st.grand_tokens += t;
        st.msg_count += 1;
        let r = st.roles.entry(role.clone()).or_default();
        r.tokens += t;
        r.count += 1;
        *st.sessions.entry(sid.clone()).or_default().entry(role.clone()).or_insert(0) += t;

        // 工具调用:assistant 消息里的 toolCall block
        if role == "assistant" {
            if let Value::Array(blocks) = &content {
                for b in blocks {
                    if let Value::Object(m) = b {
                        if m.get("type").and_then(|v| v.as_str()) == Some("toolCall") {
                            let name =
                                m.get("name").and_then(|v| v.as_str()).unwrap_or("?").to_string();
                            *st.tools.entry(name).or_insert(0) += 1;
                        }
                    }
                }
            }
        }

        // tool 输出记录(找大块)
        if role == "toolResult" && t > 0 {
            let preview: String = text.chars().take(80).collect();
            st.outputs.push(OutputRec { tokens: t, sid, seq, preview });
        }
    }

    // 时间范围(全部记录首尾,自动推导)
    if let Ok((start, end)) = conn.query_row(
        "SELECT MIN(created_at), MAX(created_at) FROM transcript_events",
        [],
        |r| Ok((r.get::<_, i64>(0)?, r.get::<_, i64>(1)?)),
    ) {
        st.start_ms = start;
        st.end_ms = end;
    }

    st.outputs.sort_by(|a, b| b.tokens.cmp(&a.tokens));
    Ok(st)
}
