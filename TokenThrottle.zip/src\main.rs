//! token-throttle:分析 QClaw 真实 token 消耗,定位可压缩的 tool 输出。
//!
//! 用法:
//!   token-throttle                      文本报告(默认库)
//!   token-throttle --db <path>          指定转录库
//!   token-throttle --json               输出 JSON
//!   token-throttle --csv <dir>          导出 4 张 CSV 表
//!   token-throttle --top 10             控制 Top N

mod analyze;
mod pi_analyze;
mod report;

use anyhow::{Context, Result};
use clap::Parser;
use rusqlite::Connection;

#[derive(Parser, Debug)]
#[command(name = "token-throttle", version, about = "分析 QClaw / pi 的 token 消耗与缓存命中,定位可压缩空间")]
struct Cli {
    /// 转录库路径(QClaw 模式,sqlite)
    #[arg(long, default_value = analyze::DEFAULT_DB)]
    db: String,

    /// pi 模式:扫 pi 会话 jsonl 分析缓存命中/费用
    #[arg(long)]
    pi: bool,

    /// pi 会话目录(--pi 时生效)
    #[arg(long, default_value = pi_analyze::DEFAULT_PI_DIR)]
    pi_dir: String,

    /// Top N 条数
    #[arg(long, default_value_t = 20)]
    top: usize,

    /// 输出 JSON(替代文本报告)
    #[arg(long)]
    json: bool,

    /// 导出 CSV 到指定目录(roles/sessions/tools/outputs 四表,仅 QClaw 模式)
    #[arg(long)]
    csv: Option<String>,
}

fn main() -> Result<()> {
    let cli = Cli::parse();

    // pi 模式:扫会话 jsonl,分析缓存命中与费用
    if cli.pi {
        let st = pi_analyze::analyze_pi(&cli.pi_dir)?;
        if cli.json {
            println!("{}", serde_json::to_string_pretty(&report::render_pi_json(&st))?);
        } else {
            print!("{}", report::render_pi_text(&st));
        }
        return Ok(());
    }

    // QClaw 模式
    let conn = Connection::open(&cli.db)
        .with_context(|| format!("打开数据库失败: {}", cli.db))?;
    let st = analyze::analyze(&conn)?;

    if cli.json {
        let value = report::render_json(&st, cli.top);
        println!("{}", serde_json::to_string_pretty(&value)?);
    } else {
        print!("{}", report::render_text(&st, cli.top));
    }

    if let Some(dir) = cli.csv {
        report::export_csv(&st, std::path::Path::new(&dir), cli.top)?;
    }

    Ok(())
}
