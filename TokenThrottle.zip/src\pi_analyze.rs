//! pi 侧会话分析:扫 ~/.pi/agent/sessions/*.jsonl,统计 token 消耗与 Prompt 缓存命中。
//!
//! 背景:pi 的每条 assistant 消息带 `usage` 字段(input/cacheRead/cacheWrite/output),
//! deepseek / MiniMax 的 prompt 缓存会自动生效,命中后输入按缓存价计费(可省 90%+)。

use anyhow::{Context, Result};
use serde_json::Value;
use std::collections::BTreeMap;
use std::path::Path;

/// pi 会话存储默认目录
pub const DEFAULT_PI_DIR: &str = "C:/Users/Administrator/.pi/agent/sessions";

/// 各模型单价(美元/百万 token):(model, input, output, cacheRead, cacheWrite)
const PRICES: &[(&str, f64, f64, f64, f64)] = &[
    ("MiniMax-M3", 0.30, 1.20, 0.060, 0.0),
    ("MiniMax-M2.7", 0.30, 1.20, 0.060, 0.375),
    ("MiniMax-M2.7-highspeed", 0.60, 2.40, 0.060, 0.375),
    ("deepseek-v4-flash", 0.14, 0.28, 0.0028, 0.0),
    ("deepseek-v4-pro", 0.435, 0.87, 0.003625, 0.0),
];

fn price_of(model: &str) -> Option<(f64, f64, f64, f64)> {
    PRICES
        .iter()
        .find(|(m, ..)| m == &model)
        .map(|(_, i, o, cr, cw)| (*i, *o, *cr, *cw))
        .or_else(|| {
            // 前缀匹配(MiniMax 系列 / deepseek 系列)
            PRICES
                .iter()
                .find(|(m, ..)| model.starts_with(m))
                .map(|(_, i, o, cr, cw)| (*i, *o, *cr, *cw))
        })
}

#[derive(Default, Debug)]
pub struct ModelStat {
    pub msgs: u64,
    pub input: u64,
    pub cache_read: u64,
    pub cache_write: u64,
    pub output: u64,
    pub billed: f64, // usage.cost.total 合计(pi 记账)
}

#[derive(Default, Debug)]
pub struct PiStats {
    pub msgs: u64,
    pub input: u64,
    pub cache_read: u64,
    pub cache_write: u64,
    pub output: u64,
    pub billed_total: f64,
    pub by_model: BTreeMap<String, ModelStat>,
}

/// 递归收集目录下所有 .jsonl 文件
fn collect_jsonl(dir: &Path, out: &mut Vec<std::path::PathBuf>) -> Result<()> {
    let mut entries: Vec<_> = std::fs::read_dir(dir)
        .with_context(|| format!("读取目录失败: {}", dir.display()))?
        .collect::<std::result::Result<_, _>>()?;
    entries.sort_by_key(|e| e.file_name());
    for e in entries {
        let p = e.path();
        if p.is_dir() {
            collect_jsonl(&p, out)?;
        } else if p.extension().is_some_and(|x| x == "jsonl") {
            out.push(p);
        }
    }
    Ok(())
}

/// 扫 pi 会话目录,统计 usage
pub fn analyze_pi(dir: &str) -> Result<PiStats> {
    let mut files = Vec::new();
    collect_jsonl(Path::new(dir), &mut files)?;
    if files.is_empty() {
        anyhow::bail!("目录下没有 .jsonl 会话文件: {dir}");
    }

    let mut st = PiStats::default();
    for fp in &files {
        let content = std::fs::read_to_string(fp)
            .with_context(|| format!("读取文件失败: {}", fp.display()))?;
        for line in content.lines() {
            if !line.contains("usage") {
                continue;
            }
            let Ok(ev) = serde_json::from_str::<Value>(line) else { continue };
            let Some(msg) = ev.get("message") else { continue };
            let Some(u) = msg.get("usage") else { continue };
            let get = |k: &str| u.get(k).and_then(|v| v.as_u64()).unwrap_or(0);

            let model = msg
                .get("model")
                .and_then(|v| v.as_str())
                .unwrap_or("?")
                .to_string();
            let billed = u
                .get("cost")
                .and_then(|c| c.get("total"))
                .and_then(|v| v.as_f64())
                .unwrap_or(0.0);

            st.msgs += 1;
            st.input += get("input");
            st.cache_read += get("cacheRead");
            st.cache_write += get("cacheWrite");
            st.output += get("output");
            st.billed_total += billed;

            let m = st.by_model.entry(model).or_default();
            m.msgs += 1;
            m.input += get("input");
            m.cache_read += get("cacheRead");
            m.cache_write += get("cacheWrite");
            m.output += get("output");
            m.billed += billed;
        }
    }
    Ok(st)
}

/// 无缓存 vs 有缓存的费用对比(按价格表重算)
pub fn cost_compare(st: &PiStats) -> (f64, f64, f64) {
    let mut no_cache = 0.0;
    let mut with_cache = 0.0;
    for (model, m) in &st.by_model {
        if let Some((i, o, cr, cw)) = price_of(model) {
            let total_in = m.input + m.cache_read + m.cache_write;
            no_cache += total_in as f64 * i / 1e6 + m.output as f64 * o / 1e6;
            with_cache += m.input as f64 * i / 1e6
                + m.cache_read as f64 * cr / 1e6
                + m.cache_write as f64 * cw / 1e6
                + m.output as f64 * o / 1e6;
        } else {
            // 未知模型:按未命中计(保守)
            let total_in = m.input + m.cache_read + m.cache_write;
            no_cache += total_in as f64 * 0.30 / 1e6 + m.output as f64 * 1.20 / 1e6;
            with_cache += total_in as f64 * 0.30 / 1e6 + m.output as f64 * 1.20 / 1e6;
        }
    }
    let saved = no_cache - with_cache;
    (no_cache, with_cache, saved)
}
