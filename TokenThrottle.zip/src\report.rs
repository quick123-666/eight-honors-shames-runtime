//! 输出层:人类可读文本、JSON、CSV 导出。

use crate::analyze::{RoleStat, Stats};
use crate::pi_analyze::{cost_compare, PiStats};
use anyhow::{Context, Result};
use chrono::{DateTime, FixedOffset, Utc};
use serde_json::{json, Value};
use std::collections::BTreeMap;
use std::path::Path;

/// 毫秒时间戳 -> 本地时间(固定 GMT+8,与机器时区一致)
fn fmt_ts(ms: i64) -> String {
    let tz = FixedOffset::east_opt(8 * 3600).unwrap();
    let Some(dt) = DateTime::<Utc>::from_timestamp(ms / 1000, 0) else {
        return format!("{ms}");
    };
    dt.with_timezone(&tz).format("%Y-%m-%d %H:%M").to_string()
}

/// 千分位
fn sep(n: u64) -> String {
    let s = n.to_string();
    let mut out = String::new();
    for (i, ch) in s.chars().enumerate() {
        if i > 0 && (s.len() - i) % 3 == 0 {
            out.push(',');
        }
        out.push(ch);
    }
    out
}

fn pct(t: u64, grand: u64) -> f64 {
    t as f64 / grand.max(1) as f64 * 100.0
}

/// 按 token 降序排序的 (role, stat)
fn sorted_roles(roles: &BTreeMap<String, RoleStat>) -> Vec<(&String, &RoleStat)> {
    let mut v: Vec<_> = roles.iter().collect();
    v.sort_by(|a, b| b.1.tokens.cmp(&a.1.tokens));
    v
}

/// 按 token 降序排序的 (sid, total, roles)
fn sorted_sessions(st: &Stats) -> Vec<(&String, u64, &BTreeMap<String, u64>)> {
    let mut v: Vec<_> = st.sessions.iter().map(|(k, m)| (k, m.values().sum::<u64>(), m)).collect();
    v.sort_by(|a, b| b.1.cmp(&a.1));
    v
}

pub fn render_text(st: &Stats, top: usize) -> String {
    let mut out = String::new();
    out.push_str("=======================================================\n");
    out.push_str("QClaw 真实 token 消耗分析(估算)\n");
    out.push_str("=======================================================\n");
    out.push_str(&format!(
        "时间范围: {} ~ {} (自动推导)\n",
        fmt_ts(st.start_ms),
        fmt_ts(st.end_ms)
    ));
    out.push_str(&format!(
        "总估算: {} tokens / {} 条消息 / {} 个会话\n\n",
        sep(st.grand_tokens),
        st.msg_count,
        st.sessions.len()
    ));

    out.push_str("--- 按角色 ---\n");
    for (role, rs) in sorted_roles(&st.roles) {
        out.push_str(&format!(
            "  {:<12} {:>9} tok ({:5.1}%)  {} 条\n",
            role,
            sep(rs.tokens),
            pct(rs.tokens, st.grand_tokens),
            rs.count
        ));
    }
    out.push('\n');

    let tool_out = st.roles.get("toolResult").map(|r| r.tokens).unwrap_or(0);
    let asst = st.roles.get("assistant").map(|r| r.tokens).unwrap_or(0);
    let user = st.roles.get("user").map(|r| r.tokens).unwrap_or(0);
    out.push_str(&format!(
        "  tool 输出(toolResult): {:>8} tok = {:4.1}%  ← 压缩可省的部分\n",
        sep(tool_out),
        pct(tool_out, st.grand_tokens)
    ));
    out.push_str(&format!(
        "  助手回复(assistant):   {:>8} tok = {:4.1}%  ← 输出 token(压缩不可省)\n",
        sep(asst),
        pct(asst, st.grand_tokens)
    ));
    out.push_str(&format!(
        "  用户输入(user):        {:>8} tok = {:4.1}%\n\n",
        sep(user),
        pct(user, st.grand_tokens)
    ));

    out.push_str("--- 按会话 ---\n");
    for (sid, total, roles) in sorted_sessions(st) {
        let map: BTreeMap<_, _> =
            roles.iter().map(|(k, v)| (k.clone(), *v)).collect();
        out.push_str(&format!("  [{}] {:>9} tok  {:?}\n", &sid[..sid.len().min(8)], sep(total), map));
    }
    out.push('\n');

    out.push_str(&format!("--- 工具调用频率 Top {} ---\n", top));
    let mut tools: Vec<_> = st.tools.iter().collect();
    tools.sort_by(|a, b| b.1.cmp(a.1));
    for (name, cnt) in tools.into_iter().take(top) {
        out.push_str(&format!("  {name}: {cnt}\n"));
    }
    out.push('\n');

    out.push_str("--- tool 输出大小分布(找大块) ---\n");
    out.push_str(&format!(
        "tool 输出总数: {} 条, 平均 {:.0} tok\n",
        st.outputs.len(),
        st.outputs.iter().map(|o| o.tokens).sum::<u64>() as f64 / st.outputs.len().max(1) as f64
    ));
    out.push_str(&format!("Top {} 最大 tool 输出:\n", top));
    for o in st.outputs.iter().take(top) {
        out.push_str(&format!(
            "  {:>7} tok  [{}] seq={}: {:?}\n",
            sep(o.tokens),
            &o.sid[..o.sid.len().min(8)],
            o.seq,
            o.preview
        ));
    }
    out
}

pub fn render_json(st: &Stats, top: usize) -> Value {
    let roles: serde_json::Map<String, Value> = st
        .roles
        .iter()
        .map(|(role, rs)| {
            (
                role.clone(),
                json!({
                    "tokens": rs.tokens,
                    "count": rs.count,
                    "percent": format!("{:.1}", pct(rs.tokens, st.grand_tokens)),
                }),
            )
        })
        .collect();

    let sessions: serde_json::Map<String, Value> = st
        .sessions
        .iter()
        .map(|(sid, roles)| {
            let total: u64 = roles.values().sum();
            (
                sid.clone(),
                json!({
                    "total_tokens": total,
                    "roles": roles,
                }),
            )
        })
        .collect();

    let tools: serde_json::Map<String, Value> = st
        .tools
        .iter()
        .map(|(name, cnt)| (name.clone(), json!(cnt)))
        .collect();

    let outputs: Vec<Value> = st
        .outputs
        .iter()
        .take(top)
        .map(|o| {
            json!({
                "tokens": o.tokens,
                "session_id": o.sid,
                "seq": o.seq,
                "preview": o.preview,
            })
        })
        .collect();

    json!({
        "time_range": { "start": fmt_ts(st.start_ms), "end": fmt_ts(st.end_ms) },
        "totals": {
            "tokens": st.grand_tokens,
            "messages": st.msg_count,
            "sessions": st.sessions.len(),
        },
        "roles": roles,
        "sessions": sessions,
        "tools": tools,
        "top_outputs": outputs,
    })
}

/// pi 侧:文本报告
pub fn render_pi_text(st: &PiStats) -> String {
    let mut out = String::new();
    out.push_str("=======================================================\n");
    out.push_str("pi 侧 token 消耗与缓存分析(usage 实测)\n");
    out.push_str("=======================================================\n");
    out.push_str(&format!("统计消息: {} 条(带 usage)\n", st.msgs));
    out.push_str(&format!("未命中输入: {:>12} tok\n", sep(st.input)));
    out.push_str(&format!("缓存命中:   {:>12} tok\n", sep(st.cache_read)));
    out.push_str(&format!("缓存写入:   {:>12} tok\n", sep(st.cache_write)));
    out.push_str(&format!("输出:       {:>12} tok\n", sep(st.output)));
    let hit = st.cache_read as f64 / (st.input + st.cache_read).max(1) as f64 * 100.0;
    out.push_str(&format!("输入侧缓存命中率: {hit:.2}%\n\n"));

    out.push_str("--- 按模型 ---\n");
    let mut models: Vec<_> = st.by_model.iter().collect();
    models.sort_by(|a, b| b.1.input.cmp(&a.1.input));
    for (model, m) in models {
        let mhit = m.cache_read as f64 / (m.input + m.cache_read).max(1) as f64 * 100.0;
        out.push_str(&format!(
            "  {:<24} {:>6} 条  命中率 {:5.1}%  记账 ${:.2}\n",
            model, m.msgs, mhit, m.billed
        ));
    }
    out.push('\n');

    let (no_cache, with_cache, saved) = cost_compare(st);
    out.push_str("--- 费用(按价格表重算) ---\n");
    out.push_str(&format!("假设无缓存:      ${:.3}\n", no_cache));
    out.push_str(&format!("当前(缓存生效):  ${:.3}\n", with_cache));
    let pct = if no_cache > 0.0 { (1.0 - with_cache / no_cache) * 100.0 } else { 0.0 };
    out.push_str(&format!("缓存帮省:         ${:.3} = {:.1}%\n", saved, pct));
    out.push_str(&format!("pi 实际记账(cost.total): ${:.3}\n", st.billed_total));
    out
}

/// pi 侧:JSON
pub fn render_pi_json(st: &PiStats) -> Value {
    let models: serde_json::Map<String, Value> = st
        .by_model
        .iter()
        .map(|(model, m)| {
            let mhit = m.cache_read as f64 / (m.input + m.cache_read).max(1) as f64 * 100.0;
            (
                model.clone(),
                json!({
                    "msgs": m.msgs,
                    "input": m.input,
                    "cacheRead": m.cache_read,
                    "cacheWrite": m.cache_write,
                    "output": m.output,
                    "hit_rate_percent": format!("{:.2}", mhit),
                    "billed_usd": m.billed,
                }),
            )
        })
        .collect();

    let (no_cache, with_cache, saved) = cost_compare(st);
    let hit = st.cache_read as f64 / (st.input + st.cache_read).max(1) as f64 * 100.0;
    json!({
        "msgs": st.msgs,
        "input": st.input,
        "cacheRead": st.cache_read,
        "cacheWrite": st.cache_write,
        "output": st.output,
        "hit_rate_percent": format!("{:.2}", hit),
        "cost": {
            "no_cache_usd": no_cache,
            "with_cache_usd": with_cache,
            "saved_usd": saved,
            "saved_percent": if no_cache > 0.0 { (1.0 - with_cache / no_cache) * 100.0 } else { 0.0 },
            "billed_total_usd": st.billed_total,
        },
        "by_model": models,
    })
}

/// 导出 CSV 到目录,写出 4 张表:roles / sessions / tools / outputs
pub fn export_csv(st: &Stats, dir: &Path, top: usize) -> Result<()> {
    std::fs::create_dir_all(dir)
        .with_context(|| format!("创建目录失败: {}", dir.display()))?;

    // roles.csv
    {
        let path = dir.join("roles.csv");
        let mut w = csv::Writer::from_path(&path)?;
        w.write_record(["role", "tokens", "percent", "count"])?;
        for (role, rs) in sorted_roles(&st.roles) {
            w.write_record([
                role,
                &rs.tokens.to_string(),
                &format!("{:.1}", pct(rs.tokens, st.grand_tokens)),
                &rs.count.to_string(),
            ])?;
        }
        w.flush()?;
    }

    // sessions.csv
    {
        let path = dir.join("sessions.csv");
        let mut w = csv::Writer::from_path(&path)?;
        w.write_record(["session_id", "total_tokens", "user", "assistant", "toolResult"])?;
        for (sid, total, roles) in sorted_sessions(st) {
            w.write_record([
                sid,
                &total.to_string(),
                &roles.get("user").unwrap_or(&0).to_string(),
                &roles.get("assistant").unwrap_or(&0).to_string(),
                &roles.get("toolResult").unwrap_or(&0).to_string(),
            ])?;
        }
        w.flush()?;
    }

    // tools.csv
    {
        let path = dir.join("tools.csv");
        let mut w = csv::Writer::from_path(&path)?;
        w.write_record(["tool", "count"])?;
        let mut tools: Vec<_> = st.tools.iter().collect();
        tools.sort_by(|a, b| b.1.cmp(a.1));
        for (name, cnt) in tools {
            w.write_record([name, &cnt.to_string()])?;
        }
        w.flush()?;
    }

    // outputs.csv
    {
        let path = dir.join("outputs.csv");
        let mut w = csv::Writer::from_path(&path)?;
        w.write_record(["tokens", "session_id", "seq", "preview"])?;
        for o in st.outputs.iter().take(top) {
            w.write_record([&o.tokens.to_string(), &o.sid, &o.seq.to_string(), &o.preview])?;
        }
        w.flush()?;
    }

    // 汇报生成的文件
    let files: Vec<String> = ["roles.csv", "sessions.csv", "tools.csv", "outputs.csv"]
        .iter()
        .map(|f| dir.join(f).display().to_string())
        .collect();
    println!("CSV 已导出到: {}", files.join(", "));
    Ok(())
}

